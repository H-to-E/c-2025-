#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
	int a;
	printf("�Է�:");
	scanf("%d", &a);
	a = a << 1;
	printf("%d", a);

}